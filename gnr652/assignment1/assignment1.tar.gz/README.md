This the folder containing files for assignment 1 for GNR652

The code is present in the linear_reg.py
and the data set is present in the data folder

The linear Regression is implemented using the two methos in the code
1) Gradient Decent
2) Closed Regression

NOTE:- The loss function of of MLE can be simplified into the MSE error therefore applying the algorithm of MLE is synonymous to applying gradient decent in our case hence the same function can be reused for MLE

How to run:-
    python2.7 linear_reg.py

